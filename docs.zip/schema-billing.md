# Schema — Billing, invoicing & finance

> **Load when:** working on charges, invoices, payments, wallets, or the
> financial ledger. See schema-quirks for the `TransactionType` enum values.

**Legend** — **PK** · **FK→** · **NN**. `__sys*` trailers omitted.

---

## 1. `patientbillingrecords` — billable charges (1:N per patient/visit)

PK `PatientBillingRecordID` char(36).
| Col | Type | Notes |
|---|---|---|
| `PatientVisitID` | char(36) FK→patientvisits | |
| `TransactionCategoryID` | char(36) FK NN | What was charged |
| `RecordDate` | datetime(3) NN | |
| `Details` | varchar(500) NN | Charge description |
| `Expense` | double NN | Amount |
| `DoctorID` | char(36) FK→hcenterusers | Treating doctor |
| `UserID` | char(36) FK NN | Creator |
| `IsLocked` | tinyint NN | Already invoiced/paid |
| `IFNumber` | varchar(100) | Insurance claim ref |

---

## 2. `patientinvoices` — aggregated invoices (1:N per patient)

PK `PatientInvoiceID` char(36).
| Col | Type | Notes |
|---|---|---|
| `PatientID` | char(36) FK NN | |
| `HCenterID` | char(36) FK NN | |
| `AddedByUserID` | char(36) FK NN | |
| `InvoiceNumber` | varchar(50) NN | Sequential per tenant (assumed) |
| `InvoiceDate`, `CreationDate` | datetime(3) NN | Invoice date, entry date |
| `PaidByPatient` | double NN | Cash from patient |
| `OldBalance` | double NN | Carried-over |
| `FinalBalance` | double NN | Outstanding |
| `CoveredByHealthInsurance` | double | Insurance portion |
| `CoveredByHospital` | double | Hospital absorption |
| `Discount` | double NN | |
| `PatientInsuranceDetailID` | char(36) FK | Which insurance |
| `HospitalName` | varchar(250) | If hospital case |
| `Migrated` | tinyint NN | Imported from old system |

---

## 3. `transactioncategories` — revenue/expense catalog (per HCenter)

PK `TransactionCategoryID` char(36).
| Col | Type | Notes |
|---|---|---|
| `HCenterID` | char(36) FK NN | |
| `TransactionCategoryName` | varchar(250) NN | |
| `IsIncome` | tinyint NN | True = income, false = expense |
| `IsCheckup` | tinyint NN | "Consult" categories |
| `DefaultPrice` | double NN | |
| `Price2`, `Price3` | double | Price tiers (e.g. insurance) |
| `IsSystem` | tinyint NN | Built-in, uneditable |
| `MedicalProcedureID`, `DiagnosticTestID`, `CPTCodeID`, `HCPCID` | char(36) FK | Optional links to procedure/test/code |

---

## 4. `wallets` — cash boxes / accounts per HCenter

PK `WalletID` char(36).
| Col | Type | Notes |
|---|---|---|
| `HCenterID` | char(36) FK NN | |
| `WalletName` | varchar(250) NN | "Main Cash", "Bank A" |
| `IsDefault` | tinyint NN | |
| `IsSystem` | tinyint NN | |
| `IsCacheBox` | tinyint NN | **typo: should be IsCashBox** — see schema-quirks |

→ No `Currency` column. Multi-currency is open question #8.

---

## 5. `hcenterfinancaltransactions` — polymorphic ledger

Every income, expense, refund, transfer, salary lives here. The
`TransactionType` enum is the discriminator (see schema-quirks §enums).

PK `HCenterFinancalTransactionID` char(36) (note: **legacy spelling**).

### Common fields
| Col | Type | Notes |
|---|---|---|
| `HCenterID` | char(36) FK NN | |
| `Details` | varchar(500) NN | Description |
| `Amount` | double NN | Signed per `TransactionType` |
| `OriginalAmount` | double | Before discount |
| `Discount` | double NN | |
| `TransactionType` | int NN | 1=Income, 2=Expense, 3=Transfer, 4=Refund, 5=Salary |
| `Notes` | longtext | |
| `AddDate` | datetime(3) NN | Posted |
| `AddUserID` | char(36) FK NN | Poster |
| `UpdateDate`, `UpdateUserID` | | Last edit |
| `CreationDate` | datetime(3) | |
| `OwnerUserID` | char(36) FK | Owner doctor (for revenue split) |
| `IFNumber` | varchar(100) | Reference |

### Polymorphic source links (only one set is non-null per row)

**If from billing/clinical:**
`PatientBillingRecordID`, `PatientInvoiceID`,
`PatientInsuranceDetailID`, `PatientID`, `TransactionCategoryID` — all
char(36) FK.

**Wallet movement (Income/Expense/Transfer):**
`WalletID` FK → destination; `SourceWallet` FK → for transfers only.

**Payroll (TransactionType = Salary):**
`EmployeeName` varchar(250), `EmployeeNumber` varchar(50),
`EmployeeUserID` char(36) FK→hcenterusers, `HCenterEmployeeID` char(36)
(external).

**Inventory:**
`InventoryItemID` char(36) — referenced but inventory tables not yet in the
schema, see open question #9.

### Query gotcha
Filter by `TransactionType` **first** in any reporting query — composite
indexes on the polymorphic FK columns alone are sparse and slow. Use
`(HCenterID, TransactionType, AddDate)` as the standard reporting predicate.
