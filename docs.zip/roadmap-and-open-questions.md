# Migration roadmap & open questions

> **Load when:** planning migration work, schema cleanup, or needing to know
> what's still TBD with the original product owner. Not needed for routine
> feature work.

---

## 1. Priority cleanups (pre-production)

| # | Action | Reason | Effort |
|---|---|---|---|
| 1 | Add all FKs from `schema-fks-indexes.md` | Prevent orphan rows | M |
| 2 | Add all indexes from `schema-fks-indexes.md` | 10–100× speedup | S |
| 3 | Standardize `int(11)` vs `tinyint(1)` for boolean-like fields | Type safety | M |
| 4 | Document & enforce enums in code | Avoid magic numbers (see schema-quirks §enums) | M |
| 5 | Add `HCenterID` to `patientvisits` (denormalize) | Faster tenant filtering | S |
| 6 | Normalize `pvpriskstratificationchecks` (30 cols → row-per-check) | Schema sanity | L |
| 7 | Move `__sys*` to `audit_*` shadow tables | Reduce row width | L |
| 8 | Add `created_at`, `updated_at` everywhere | Standard audit | M |
| 9 | Migrate `char(36)` → `BINARY(16)` GUIDs | 60% smaller, faster index | XL |
| 10 | Split `hcenterfinancaltransactions` into typed tables (income, expense, transfer) | Cleaner queries | XL |

---

## 2. Data-quality probes (run during migration)

```sql
-- Orphaned visits
SELECT v.* FROM patientvisits v
LEFT JOIN patients p ON p.PatientID = v.PatientID
WHERE p.PatientID IS NULL;

-- Visits with soft-deleted patients
SELECT v.* FROM patientvisits v
JOIN patients p ON p.PatientID = v.PatientID
WHERE p.IsDeleted = 1 AND v.IsDeleted = 0;

-- Duplicate national IDs within an HCenter
SELECT HCenterID, NationalID, COUNT(*)
FROM patients
WHERE IsDeleted = 0
GROUP BY HCenterID, NationalID
HAVING COUNT(*) > 1;

-- Future-dated visits
SELECT * FROM patientvisits WHERE VisitDate > NOW();

-- Sign mismatches in finance
SELECT * FROM hcenterfinancaltransactions
WHERE TransactionType = 1 AND Amount < 0;  -- Income should be positive
```

---

## 3. Live migration strategy

1. **Snapshot** production DB (logical dump).
2. **Restore to staging.** Test FK/index additions; fix orphans.
3. **Build new app against staging schema.**
4. **Dual-write.** Old app → old DB. New app → both, via CDC
   (Debezium / MaxScale CDC).
5. **Cutover.** Drain old app, switch traffic, validate.
6. **Decommission** old app after 90-day reconciliation.

---

## 4. Open questions (need owner sign-off)

These block specific work — flag the blocker before starting that work.

| # | Question | Blocks |
|---|---|---|
| 1 | Exact enum values for `Sex`, `VisitType`, `Outcome`, `Intensity`, `TransactionType`, `SubscriptionType`, `UserType`, `DeliveryType` | Any DTO mapping; assumptions captured in schema-quirks §enums |
| 2 | Is Devart offline sync (`__sys*`) still used? | Whether columns can be dropped |
| 3 | Existing app's password / auth mechanism | `hcenterusers` has no password column |
| 4 | Where uploaded files live (`PhotoFilename`, `ReportsLogo`, `HomePagePhotoUrl`) | FS path? S3? Blob? |
| 5 | Triggers, stored procedures, views not in the dump? | Hidden business logic risk |
| 6 | Is `HCenterID` on `patientvisits` intentionally absent? | Roadmap #5; performance |
| 7 | eClaim Link integration endpoints / formats | Insurance claim flow |
| 8 | Currency handling — single or multi? | `wallets` has no currency col |
| 9 | Inventory module — `InventoryItemID` referenced, no inventory tables | Whether to build inventory now |
| 10 | Patient portal scope — is `OnlinePassword` actively used? | Portal priority |
| 11 | Reporting tool today — Crystal? Stimulsoft? | Migration of `Report*Ar` templates |
| 12 | Retention policy (visits, invoices) | Partitioning strategy |
| 13 | SMS / email gateway provider | Appointment reminders |
| 14 | Compliance per deployment region (HIPAA? DHA? local) | Encryption + audit baseline |
| 15 | DR RTO / RPO targets | Backup architecture |

---

## 5. Assumptions made in this doc set

1. **Tenant = HCenter.** One DB, shared schema, `HCenterID` discriminator.
2. **Soft delete is intended** on `patients` and `patientvisits`; orphans
   preserved.
3. **Bilingual = English + Arabic** only (no other RTL languages).

If any of these turns out wrong, the impact is wide — fix the assumption,
then sweep schema docs.
