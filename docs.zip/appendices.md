# Appendices — Table inventory & acronym glossary

> **Load when:** §A — "which file is table X in?" · §B — encountering an
> unfamiliar medical acronym. Not for routine feature work.

---

## §A — Table inventory (file routing)

93 tables total. Find a table, then load that file.

### → `docs/schema-reference.md`
**System (3)** `__sysocsdeletedrows`, `__sysocstrackedobjects`, `__systxcommitsequence`
**Geographic & demographic (4)** `countries`, `cities`, `humanraces`, `maritalstatuses`
**Medical coding & reference (16)** `specialities`, `bodysystems`, `bodysystemannotationimages`, `bodysystemschecklistitems`, `checklistitems`, `medicalconditions`, `medicalprocedures`, `medicines`, `immunizationsvaccines`, `symptoms`, `diagnostictests`, `modalities`, `cptcodes`, `hcpcs`, `icd10-cm2012`, `denverscreeningtestitems`
**Growth percentiles (4)** `agebmipercentiles`, `ageheightpercentiles`, `ageweightpercentiles`, `agehcpercentiles`

### → `docs/schema-tenant-users.md`
**HCenter / tenant (5)** `hcenters`, `hcenterpage`, `hcentersystemsettings`, `hcenterspecialities`, `hcenterscheduleitems`
**Users & permissions (5)** `hcenterusers`, `permissions`, `hcuserspermissions`, `hcupvqsections`, `hcenteruserfavcptcodes`

### → `docs/schema-patient-core.md`
**Patient master (8)** `patients`, `patientarabicinfo`, `patientadditionalinfo`, `patientsaddetails`, `patientjobs`, `patienteducationalhistory`, `patientspecialnotes`, `patientchecklist`, `patienttestbehaviors`, `patientinsurancedetails`

### → `docs/schema-patient-history.md`
**General history (7)** `allergies`, `chronicdiseases`, `patientlongtermmedicines`, `patientproblems`, `pfihereditarydiseases`, `patientimmunizationhistory`, `patientimmunizations`, `patientlabrequests`

### → `docs/schema-patient-pediatric-obgyn.md`
**Pediatric history (8)** `patientantenatalhx`, `patientnatalhx`, `patientneonatalhx`, `patientgdhx`, `patientnutritionalhx`, `patientprimarydentaleruptions`, `patientpermanentdentaleruptions`, `ppfghistorycheclistitems`
**OB/GYN history (3)** `patientmalerelatedhistory`, `patientfemalerelatedhistory`, `patientpreviouspregnancies`

### → `docs/schema-patient-clinical.md` *(or visits — depending on your split)*
**Patient clinical (8)** `patientgeneralappearance`, `patientgeneralreviewquestionaire`, `patientbodysystemreview`, `patientbodysystemphysicalexam`, `pbspexamchecklistitem`, `patientdiagnosticstudies`, `patientdstitems`, `patientechocardiogramtests`, `patienttests`, `procedurehistory`

### → `docs/schema-visits-row.md`
**Visit row** `patientvisits`

### → `docs/schema-visits-subrecords.md`
**Visit sub-records (14)** `aftervisitrecommendations`, `pvassessmentconditions`, `pvpmhconditions`, `pvpmhmedications`, `pvplanmedications`, `pvgprescription`, `pvrevisits`, `pvpregnancydetails`, `pvpriskstratificationchecks`, `pvpinitialexam`, `prenatalflowsheetitems`, `pvfertilitydetails`, `pvfertilityflowsheetitems`, `patientpasiscore`

### → `docs/schema-billing.md`
**Billing & finance (5)** `patientbillingrecords`, `patientinvoices`, `transactioncategories`, `wallets`, `hcenterfinancaltransactions`

---

## §B — Medical acronym glossary

| Acronym | Full form |
|---|---|
| ABO | Blood group system (A, B, AB, O) |
| BMI | Body Mass Index |
| BP / SBP / DBP | Blood Pressure / Systolic / Diastolic |
| BVD | Back Vertex Distance (optics) |
| CC | Chief Complaint |
| CCA | Cardiovascular Congenital Anomaly |
| CP | Chest Pain |
| CPD | Cephalopelvic Disproportion |
| CPT | Current Procedural Terminology (AMA billing codes) |
| CRD | Chronic Renal Disease |
| DDH | Developmental Dysplasia of the Hip |
| DMR | Developmental delay / Mental Retardation (older term) |
| EDC | Estimated Date of Confinement (delivery) |
| EKG / ECG | Electrocardiogram |
| FHRD | Fetal Heart Rate Detected |
| FSH | Follicle Stimulating Hormone |
| GnRH | Gonadotropin-Releasing Hormone |
| HC | Head Circumference |
| HCPCS | Healthcare Common Procedure Coding System (US) |
| HEENT | Head, Eyes, Ears, Nose, Throat |
| HPI | History of Present Illness |
| ICD-10-CM | International Classification of Diseases, 10th rev., Clinical Modification |
| ICSI | Intracytoplasmic Sperm Injection |
| IUI | Intrauterine Insemination |
| IVS | Interventricular Septum |
| LA | Left Atrium |
| LH | Luteinizing Hormone |
| LMP | Last Menstrual Period |
| LV / LVEDD / LVESD | Left Ventricle / End-Diastolic / End-Systolic Diameter |
| MMR | Measles, Mumps, Rubella vaccine |
| NICU | Neonatal Intensive Care Unit |
| NYHA | New York Heart Association (cardiac functional class) |
| OC | Obstetric Complications |
| OD / OS | Oculus Dexter (right) / Oculus Sinister (left) eye |
| OID | Other Inherited Disorder |
| PASI | Psoriasis Area Severity Index |
| PCA | Pediatric Cardiac Anomaly |
| PD | Pupillary Distance |
| PLVW | Posterior Left Ventricular Wall |
| PMH | Past Medical History |
| PPD | Posterior Pericardial Distance / Purified Protein Derivative |
| Rh | Rhesus factor (Rh+ / Rh-) |
| ROS | Review of Systems |
| SAD | Substance Abuse Disorder |
| SGA | Small for Gestational Age |
| SOAP | Subjective, Objective, Assessment, Plan (note format) |
| TESA | Testicular Sperm Aspiration |
| TORCH | Toxoplasmosis, Other (syphilis, varicella), Rubella, Cytomegalovirus, Herpes |
| TPAL | Term, Preterm, Abortion, Living children |
| TSD | Tay-Sachs Disease |
| US | Ultrasound |

---

*Doc set v3.0 — refactored for on-demand loading from the original v2.0
"Advanced" structure dated 18 May 2026. 93 tables · ~1,400 columns · FK
statements and indexes are in `schema-fks-indexes.md`.*
