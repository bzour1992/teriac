# Security, ops, performance

> **Load when:** working on auth, encryption, audit, backups, deployment,
> performance tuning, observability, or anything HIPAA-adjacent.

---

## 1. Compliance frameworks (by deployment region)

| Country | Framework |
|---|---|
| USA | HIPAA, HITECH |
| EU | GDPR + national health laws |
| UAE | Federal Law No. 2 of 2019 (Health ICT), DHA / DOH circulars |
| KSA | NPHIES, PDPL |
| Jordan | Personal Data Protection Law 2023 |

Patient health data = **PHI**.

---

## 2. Encryption

- **At rest:** MariaDB TDE on data + log files. S3 buckets SSE-KMS for photo/
  report storage.
- **In transit:** TLS 1.2+ everywhere, including DB
  (`useSSL=true&requireSSL=true`).
- **Field-level:** Application-encrypt the most sensitive columns
  (`NationalID`, `PassportNumber`) via `EF.EncryptColumn`. Defends against
  DBA/backup-tape leaks.

---

## 3. Password & auth

- `patients.OnlinePassword` — argon2id (or bcrypt cost ≥ 12).
- `hcenterusers` has **no password column** — external IdP via OIDC (Keycloak
  or Auth0). MFA required for admin + clinical accounts.
- JWT access token: 15 min. Refresh tokens rotating, 30 days max.
- Lock account after 5 failed logins.

---

## 4. Audit trail

`__sys*` columns only track the latest change. For compliance, append-only:

```
audit_log
  AuditID         bigint AI PK
  EventTime       datetime(6) NN
  UserID          char(36) NN
  HCenterID       char(36) NN
  IPAddress       varchar(45) NN
  Action          varchar(50) NN   -- View|Create|Update|Delete|Export|Print
  EntityType      varchar(100) NN  -- 'Patient', 'PatientVisit'…
  EntityID        char(36) NN
  PatientContext  char(36) NULL    -- always log which patient was touched
  ChangedFields   json NULL
  PreviousValues  json NULL
  NewValues       json NULL
  CorrelationID   char(36) NN
indexes:
  (HCenterID, EventTime DESC)
  (PatientContext, EventTime DESC)
  (UserID, EventTime DESC)
```

**Log every read of PHI**, not just writes (HIPAA "access" requirement).

---

## 5. Soft delete

Introduce `BaseAuditableEntity` (`IsDeleted`, `DeletedBy`, `DeletedAt`).
Apply EF global filter (`HasQueryFilter`) consistently.

---

## 6. Tenant isolation — 4 lines of defense

1. **JWT** signs `hcenter_id` claim
2. **API middleware** sets `TenantContext` from claim
3. **EF global filter** auto-filters every query by `HCenterID`
4. **Sanity check in `SaveChanges()`** — assert no `HCenterID` mismatch on any
   modified entity before commit

Skipping any one of these is a P0 bug.

---

## 7. Patient rights & retention

- **GDPR Art. 15 export:** `/admin/patients/{id}/export` → ZIP of all PHI.
- **Research anonymization:** redact name, DOB → year only, mobile, address.
- **Right-to-be-forgotten:** anonymize, don't hard-delete (clinical records
  must be retained 10+ years).

---

## 8. Backups

| Backup | Frequency | Retention |
|---|---|---|
| Full DB dump (encrypted) | Daily 02:00 UTC | 30 days |
| Incremental binlog | Hourly | 7 days |
| Off-site copy | Daily | 1 year |
| Photo/report blob snapshots | Daily | 30 days |
| Restore drill | Quarterly | DR runbook |

---

## 9. Performance & query patterns

| Pattern | Frequency | Optimization |
|---|---|---|
| Patient typeahead | Very high | FULLTEXT on names + Redis cache for active center |
| Today's appointments by doctor | High | `(Doctor, ScheduledInDate)` idx + 1-min Redis cache |
| ICD-10 / CPT search | High | Meilisearch (sub-50ms) or FULLTEXT + Redis L2 |
| Patient visit history | Medium | `(PatientID, VisitDate DESC)` idx |
| Daily revenue report | Per shift | `(HCenterID, AddDate)` idx + nightly materialized summary |
| Demographic dashboard | Low | Pre-aggregated nightly via Hangfire |

### Partitioning (>10M rows)
- `hcenterfinancaltransactions` by `YEAR(AddDate)` — partitions p2023…p2026,
  pmax. Archive oldest to cold storage.
- `patientvisits` similarly by visit year.
- ICD-10 — skip partitioning; Meilisearch handles search.

---

## 10. Caching (Redis)

| Cache | TTL | Invalidation |
|---|---|---|
| Lookups (countries, races, marital, body systems) | 24h | Admin edit |
| HCenter settings | 1h | Settings update |
| User permissions | 15min | Permission change |
| Today's schedule per doctor | 60s | Schedule event |
| Patient summary | 5min | Patient update |
| ICD/CPT search results | 1h | Data refresh only |

---

## 11. Read replicas (50+ HCenters, 1000+ users)

- 1 primary (writes)
- 2 read replicas (round-robin for read-only endpoints)
- Route via MaxScale or ProxySQL

---

## 12. Background jobs (Hangfire)

| Job | Schedule |
|---|---|
| Daily P&L roll-up | 02:30 UTC daily |
| Invoice age report | Weekly Mon 06:00 |
| Appointment reminder SMS | Hourly 08:00–20:00 |
| Cleanup expired sessions | Every 15 min |
| Audit log retention pruning | Monthly |
| ICD/CPT search index rebuild | Weekly Sun 03:00 |

---

## 13. Deployment

### Dev — Docker Compose
Services: `api`, `db` (mariadb:11), `redis` (redis:7-alpine),
`meilisearch` (getmeili/meilisearch:v1.5), `minio` (S3-compatible),
`keycloak` (quay.io/keycloak/keycloak:24, `start-dev`).
API env: `ConnectionStrings__Default`, `Redis__Connection`, `S3__Endpoint`,
`Keycloak__Authority`. See `docker-compose.yml` for actual ports.

### Prod — Kubernetes
| Component | Type | Replicas |
|---|---|---|
| `teriac-api` | Deployment | 3+ (HPA on CPU 60%) |
| `teriac-web` | Deployment | 2 (CDN-fronted) |
| `mariadb-primary` | StatefulSet | 1 |
| `mariadb-replica` | StatefulSet | 2 |
| `redis` | StatefulSet | 1 (or Redis Cluster 3) |
| `meilisearch` | StatefulSet | 1 |
| `keycloak` | Deployment | 2 |
| `hangfire-worker` | Deployment | 2 |

Ingress: NGINX + cert-manager. Storage: cloud block storage, daily snapshots.

### Dockerfile shape
Multi-stage: `mcr.microsoft.com/dotnet/sdk:8.0-alpine` (build) →
`mcr.microsoft.com/dotnet/aspnet:8.0-alpine` (runtime). Non-root user 1000.
`ENTRYPOINT ["dotnet", "Teriac.Api.dll"]`. Actual Dockerfile in repo root.

### CI/CD (GitHub Actions outline)
Restore → build (Release) → test (trx logger) → `dotnet list package
--vulnerable --include-transitive` → on main, Docker build & push to
`registry.example.com/teriac-api:${{ github.sha }}`.
Service container: mariadb:11 with `MARIADB_ROOT_PASSWORD=test`, port 3306.

---

## 14. Observability

- **Logs:** Serilog → Seq (dev) → Elastic (prod). Structured with
  `CorrelationId`, `HCenterId`, `UserId`, `PatientId`.
- **Metrics:** OpenTelemetry → Prometheus → Grafana. Custom metrics:
  visits-per-minute, invoice-generation-time, payment-success-rate.
- **Tracing:** OTel → Tempo / Jaeger. Trace ID propagated into MariaDB
  query comments.
- **Alerts:** API 5xx >1%, DB pool >80%, audit log write failures, anomalous
  bulk PHI access.
