# Schema — Reference data (system, geo, medical coding)

> **Load when:** working with lookups — countries, cities, ICD-10, CPT, HCPCS,
> body systems, medical conditions, growth percentiles, Denver screening.
> **Don't load** for routine patient or visit work — `__sys*` system tables
> documented here are not user-facing.

**Legend** — **PK** primary key · **FK→** foreign key · **NN** not null ·
**AI** auto-increment. Every domain table also trails `__sysChangeTxBsn`,
`__sysInsertTxBsn`, `__sysTrackingContext` — omitted below. Treat as opaque.

---

## 1. System sync tables (Devart offline sync engine)

Skip these unless debugging sync. They are not application-readable.

- **`__sysocsdeletedrows`** — tombstones for physically deleted rows.
  Cols: `__sysTName` (table), `__sysRK` (PK blob), `__sysDeleteTxBsn`,
  `__sysInsertTxCsn`, `__sysDeletedTime`, `__sysTrackingContext`.
- **`__sysocstrackedobjects`** — registry of tracked tables/columns.
  Cols: `__sysTName`, `__sysTrackOpt`, `__sysTrackType`, `__sysTrackColOrd`.
- **`__systxcommitsequence`** — commit-order log.
  Cols: `__sysTxBsn` (indexed), `__sysTxCsn` (PK), `__sysCommitTime`.

→ Open question #2 (roadmap): is offline sync still in use?

---

## 2. Geographic & demographic lookups

### `countries`
PK `CountryID` char(36). Cols: `CountryName` (NN), `CountryCodeISO3`,
`CountryCodeISO2`, `PhoneCode` (e.g. +962), `NationalityText`.

### `cities`
PK `CityID` char(36). `CityName` (NN), `CountryID` FK→countries (NN).

### `humanraces`
PK `HumanRaceID` char(36). `RaceName` (NN) — Caucasian, Arab, African, etc.

### `maritalstatuses`
PK `MaritalStatusID` char(36). `MaritalStatus` (NN) — Single, Married, etc.

---

## 3. Medical coding & reference

### `specialities`
PK `SpecialityID` char(36).
| Col | Type | Notes |
|---|---|---|
| `SpecialityName` | varchar(150) NN | Cardiology, Pediatrics… |
| `Description` | longtext | |
| `SpecialtyGroup` | varchar(2) NN | Group code |
| `SpecialtyID` | varchar(50) | External (eClaim Link) code |

### `bodysystems`
PK `BodySystemID` char(36).
| Col | Type | Notes |
|---|---|---|
| `BodySystemName` | varchar(50) NN | Cardiovascular, Respiratory… |
| `BodySystemDescription` | varchar(500) | |
| `SmallImageFileName`, `MediumImageFilename`, `LargeImageFilename` | varchar(255) | Thumbnail → full |
| `BodySystemOrder` | int NN | Display order |

### `bodysystemannotationimages`
Annotatable anatomical diagrams. PK `BodySystemAnnotationImageID` char(36),
FK→bodysystems, `Filename`, `ImageTitle` (NN).

### `bodysystemschecklistitems`
Review-of-systems questions per body system. **PK is `bigint AI`** (not GUID).
Cols: `BodySystemChecklistItemName` (NN), `AdditionalQuestions`,
`BodySystemID` FK NN, `OrderWithinSystem` NN.

### `checklistitems`
Generic patient checklists (vaccinations, screenings).
PK `ChecklistItemID` char(36). Cols: `ChecklistItemName` (NN), `Description`,
`ImageFile`.

### `medicalconditions`
Master diagnosis list. PK char(36).
| Col | Type | Notes |
|---|---|---|
| `MedicalConditionName` | varchar(250) NN | |
| `Description` | longtext | |
| `IsAllergy`, `IsHereditary`, `IsChronic` | tinyint NN | Classification flags |
| `CategoryText` | varchar(50) | |
| `IsVerified` | tinyint NN | Admin-approved vs user-added |
| `AddedBy` | varchar(250) NN | Username |
| `SearchKeywords` | longtext | Comma-separated aliases |
| `DateAdded` | datetime(3) | |

### `medicalprocedures`
PK char(36). Cols: `MedicalProcedureName` (NN), `MedicalProcedureDescription`,
`IsVerified` NN, `AddedBy` NN, `DateAdded`.

### `medicines`
Drug master. PK char(36).
| Col | Type | Notes |
|---|---|---|
| `TradeName` | varchar(500) | Brand |
| `scientificName` | varchar(500) | Generic — **legacy casing**, see schema-quirks |
| `Description` | longtext | |
| `IsVerified`, `AddedBy`, `DateAdded` | | Standard provenance |
| `CityID`, `CountryID` | char(36) FK | Regional availability (Country NN) |

### `immunizationsvaccines`
PK char(36). `ImmunizationsVaccineName` (NN), provenance fields.

### `symptoms`
PK char(36). `SymptomName` longtext NN, `Description`, provenance.

### `diagnostictests`
PK char(36). `DiagnosticTestName` (NN), `Description`,
`DiagnosticTestType` (enum — see schema-quirks), provenance.

### `modalities`
Imaging modalities. PK char(36). `ModalityName` (NN), `ModalityType` (int),
`Description`.

### `cptcodes`
PK `CPTCodeID` char(36).
| Col | Type | Notes |
|---|---|---|
| `CPT_CODE` | varchar(9) | 5-digit code |
| `SHORT_DESCRIPTION`, `LONG_DESCRIPTION`, `FULL_DESCRIPTION` | varchar(500) | |
| `SGroup` | varchar(50) | Specialty grouping |
| `SpecialtyID` | char(36) FK→specialities | |

### `hcpcs`
PK `HCPCID` char(36). `HCPCCode` (NN), `HCPCShortDescription` (NN),
`HCPCLongDescription` (NN).

### `icd10-cm2012`
~65k rows. PK `ICD10ID` bigint AI. Cols: `Code` (NN), `ShortDesc`, `LongDesc`,
`Type` (1=Header, 2=Billable — see schema-quirks).

### `denverscreeningtestitems`
Denver Developmental Screening Test.
PK `ItemID` char(36).
| Col | Type | Notes |
|---|---|---|
| `ItemName` | varchar(250) NN | Milestone |
| `ItemCategory` | int NN | 1-4 (see schema-quirks) |
| `V25`, `V50`, `V75`, `V90` | double NN | Age (months) at each percentile |
| `ItemType` | varchar(50) | Display type |
| `ValueOrder` | int NN | Sort order |

---

## 4. Growth percentile tables

Four tables, identical structure:
`agebmipercentiles`, `ageheightpercentiles`, `ageweightpercentiles`,
`agehcpercentiles`.

| Col | Type | Notes |
|---|---|---|
| `Age{Metric}PercentileID` | char(36) PK | One per table |
| `AgeInMonths` | double NN | |
| `Gender` | int NN | 1=Male, 2=Female |
| `ThirdPercentile`, `FifthPercentile`, `TenthPercentile`, `TwentyFifthPercentile`, `FifteethPercentile`*, `SeventyFifthPercentile`, `NineteethPercentile`*, `NintyFifthPercentile`*, `NintySeventhPercentile`* | double NN | 3rd, 5th, 10th, 25th, **50th** (typo), 75th, **90th** (typo), **95th**, **97th** |

\* See schema-quirks §typos.
