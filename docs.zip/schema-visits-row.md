# Schema — Visit row

> **Load when:** working on visit creation, visit list, visit detail header,
> or anything that touches the `patientvisits` table directly. For visit
> sub-records (assessment, plan, prescriptions, revisits, etc.), load
> `schema-visits-subrecords.md`.
>
> **Tables in this file:** `patientvisits` only.

**Legend** — **PK** · **FK→** · **NN**. `__sys*` omitted.

---

> **MERGE NOTE:** Paste your existing column-by-column content for the
> `patientvisits` table here. Keep:
> - **All columns** (this is the central visit table — full fidelity needed)
> - Notes about `IsDeleted`, `VisitDate`, `VisitType`, `Outcome`
>
> Cross-references to add:
> - `VisitType`, `Outcome` enums → schema-quirks §enums
> - **No `HCenterID` column** — flag this prominently; tenant filter goes via
>   `patients`. Roadmap item #5 plans to denormalize.
> - Soft delete via `IsDeleted` — security-and-ops §5
