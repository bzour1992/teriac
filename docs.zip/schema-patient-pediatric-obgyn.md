# Schema — Patient history (pediatric & OB/GYN)

> **Load when:** working on pediatric history forms (antenatal, natal,
> neonatal, growth & development, nutrition, dental eruptions) or OB/GYN
> history (male, female, previous pregnancies). For general history, load
> `schema-patient-history.md`.
>
> **Pediatric tables:** `patientantenatalhx`, `patientnatalhx`,
> `patientneonatalhx`, `patientgdhx`, `patientnutritionalhx`,
> `patientprimarydentaleruptions`, `patientpermanentdentaleruptions`,
> `ppfghistorycheclistitems`.
>
> **OB/GYN tables:** `patientmalerelatedhistory`,
> `patientfemalerelatedhistory`, `patientpreviouspregnancies`.

**Legend** — **PK** · **FK→** · **NN**. `__sys*` omitted.

---

> **MERGE NOTE:** Paste your existing content for the 11 tables above here.
> Cross-refs:
> - `DeliveryType` enum → schema-quirks
> - Denver screening references → schema-reference
> - Acronyms (TPAL, EDC, TORCH, etc.) → appendices §B
