# Schema — Tenant (HCenter) & users

> **Load when:** working on tenant settings, user accounts, permissions, the
> appointment scheduler, or anything that interacts with `HCenterID`.

**Legend** — **PK** · **FK→** · **NN** · **AI**. `__sys*` trailers omitted.

---

## 1. Healthcare Center (tenant root)

Every patient, user, and financial record is scoped to one HCenter.

### `hcenters`
PK `HCenterID` char(36).
| Col | Type | Notes |
|---|---|---|
| `HCenterName` | varchar(500) NN | Display name |
| `HCenterNameRep` | varchar(500) | Reports name (often Arabic) |
| `IsOneDoctor` | tinyint NN | Single-doctor practice flag |
| `Email`, `Phone` | varchar(250) | |
| `IsActive` | tinyint NN | Soft inactive |
| `SubscriptionType` | int NN | Enum — see schema-quirks |
| `CityID`, `CountryID` | char(36) FK | Country NN |
| `ReportsLogo` | varchar(255) | Logo filename |
| `ReportsWorkingTimes`, `ReportAddress` | varchar(500) | Report header fields |
| `SupportStartDate` | datetime(3) NN | Subscription start |
| `LastRenewalDate` | datetime(3) | |
| `HCenterInitials` | varchar(2) | E.g. "AH" |
| `eClaimLinkID` | varchar(25) | UAE facility ID |
| `ClinicManager`, `ClinicManagerEmail`, `ClinicManagerMob`, `ClinicManagerOfficePhone` | | Manager contact |

### `hcenterpage` — public landing page (1:1)
Shared PK `HCenterID` FK→hcenters.
Cols: `FriendlyUrl` (NN, slug), `HCenterDisplayNameEn` (NN),
`HCenterDisplayNameOther` (Arabic), `Description` longtext, `HomePagePhotoUrl`,
`Address` longtext, `FeedbackEmail`, `HomePageCoverPhotoUrl`.

### `hcentersystemsettings` — per-tenant config (1:1)
Shared PK `HCenterID`. All flags are `tinyint(1)` (boolean) unless noted as
`int(11)` for 3-state requireds (0=not shown, 1=optional, 2=required — see
schema-quirks).

**Patient-registration "required" flags** (mix of tinyint and int):
`IsHeightWeightRequired`, `IsPatientAddressRequired`*,
`IsOrganizationOccupationRequired`, `IsGeneralAppearanceRequired`*,
`IsHumanRaceRequired`, `IsMaritalStatusRequired`,
`IsPatientEnglishNameRequired`, `IsPatientArabicNameRequired`,
`IsPatientChecklistRequired`, `IsPatientFamilyHistoryRequired`*,
`IsSystemsReviewRequired`, `IsSystemsPhysicalExamRequired`,
`AreRoutinesPatternsRequired`*, `AreHereditaryDiseasesRequired`,
`AreAllergiesRequired`, `AreChronicDiseasesRequired`.
\* = `int(11)` 3-state.

**Other**:
| Col | Type | Notes |
|---|---|---|
| `DefaultPayment` | int NN | Default payment method enum |
| `PreferredCurrency` | varchar(50) | "JOD", "USD", "AED" — but `wallets` has no currency col, see open Q #8 |
| `CanDoctorsEditPatientDemographicInformation` | tinyint NN | |
| `OnlyVisitDoctorCanEditVisitRecords` | tinyint NN | |
| `PreventEditingPatientVisitWhenStatusIsResolvedOrFailed` | tinyint NN | |
| `OnlyCenterAdminIsAllowedToDeleteAttachments` | tinyint NN | |
| `NumberOfOperationRooms` | int NN | OR count for scheduling |
| `UseAdminInsuranceCompanies` | tinyint NN | Master vs own list |
| `IsLockedData` | tinyint NN | Read-only mode |

### `hcenterspecialities` — specialties offered (M:N)
PK `HCenterSpecialityID` char(36).
Cols: `HCenterID` FK NN, `SpecialityID` FK NN, `DefaultPayment` (consult fee),
`ShowOnProfile` tinyint NN.

### `hcenterscheduleitems` — appointment calendar
PK `HCenterScheduleItemID` char(36).
| Col | Type | Notes |
|---|---|---|
| `HCenterID` | char(36) FK NN | |
| `Name` | longtext | Appointment label / patient name |
| `ContactPhone`, `ContactEmail` | | |
| `ScheduledInDate`, `ScheduledToDate` | datetime(3) NN | Start, end |
| `Doctor` | char(36) FK→hcenterusers | |
| `Notes` | longtext | |
| `IsVerified`, `IsDone` | tinyint NN | Confirmation, completion |
| `AddSchedulingOfficer` | char(36) FK NN | Creator |
| `AddedDate` | datetime(3) NN | |
| `UpdatedDate`, `UpdateSchedulingOfficer` | | Last edit |
| `LabelID` | int NN | Color enum — see schema-quirks |
| `StatusID` | int NN | Workflow enum — see schema-quirks |
| `PatientID` | char(36) FK | Optional patient link |
| `PatientVisitID` | char(36) FK | Visit created from this appointment |
| `PVRevisitID` | char(36) FK | If revisit |
| `Location` | varchar(250) | Room |
| `ByDoctor` | tinyint NN | Doctor self-scheduled |
| `IsSurgery` | tinyint NN | Surgery vs clinic |
| `NotForPatient` | tinyint NN | Internal blocker (lunch, meeting) |
| `ProcedureHistoryID` | char(36) FK | |
| `PVPlanProceduresCPTID` | char(36) | Planned CPT reference |

---

## 2. Users & permissions

### `hcenterusers`
All staff (doctors, nurses, receptionists, admins).
PK `UserId` char(36). **No password column** — auth via Keycloak (OIDC), see
security-and-ops §12.2.

| Col | Type | Notes |
|---|---|---|
| `UserName` | varchar(256) | Login name |
| `ConfirmationCode` | varchar(50) | Email confirm |
| `UserType` | int NN | Enum — see schema-quirks |
| `IsAdmin` | tinyint NN | Tenant admin |
| `FirstName` (NN), `SecondName`, `ThirdName`, `LastName` | varchar(50) | |
| `Position` | varchar(50) | Job title |
| `Description` | longtext | Bio |
| `PhotoFilename` | varchar(250) | Avatar |
| `DefaultPayment` | double | Default consult fee |
| `SchedulingOfficer` | char(36) FK→hcenterusers | Assigned scheduler |
| `IsPublic` | tinyint NN | Show on public profile |
| `IsActive` | tinyint NN | |
| `HCenterID` | char(36) FK NN | |
| `HCenterSpecialityID` | char(36) FK | Primary specialty |
| `ReportUsername`, `ReportSpeciality`, `ReportOther1`, `ReportOthers2` | varchar | English report header lines |
| `ReportUsernameAr`, `ReportSpecialityAr`, `ReportOther1Ar`, `ReportOthers2Ar` | varchar | Arabic counterparts |
| `eClaimLinkID` | varchar(25) | UAE clinician ID |
| `eCliamProfessionalName` | varchar(250) | **typo** — see schema-quirks |
| `IsFinancialAdmin` | tinyint NN | Financial module access |
| `IsOptometrist` | tinyint NN | |
| `IsOperationsRoomAppointmentsManager` | tinyint NN | OR scheduling admin |

### `permissions`
PK `PermissionID` bigint (not AI). `PermissionName` (NN, e.g.
"Patients.Create"), `PermissionType` (enum).

### `hcuserspermissions` — M:N user↔permission
Composite PK (`UserID`, `PermissionID`). Both FK NN.

### `hcupvqsections`
Per-user toggles for which sections appear in the patient-visit questionnaire.
Shared PK `UserId` FK→hcenterusers. All `tinyint(1)` NN unless noted:
`VitalSigns`, `StandardMeasurements`, `Immunization`, `HabitDetails`,
`FDHistory`, `PatientMedications`, `HistoryOfIllness`, `Allergies`,
`GeneralAppearance`, `GeneralReview`, `PhysicalExamination`, `Diagnostics`,
`ProceduresPlan`, `VisitAttachments`, `ChronicDiseases`, `ProceduresHistory`,
`SystemReviews`.
Plus `DefaultBodySystem` varchar(250).

### `hcenteruserfavcptcodes`
User favorite CPT codes. PK char(36), `CPTCodeID` FK NN, `HCenterUserID` FK NN.
