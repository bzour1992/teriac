# API endpoints & DTOs

> **Load when:** designing or modifying an HTTP endpoint, writing/reading
> a DTO, or working on the API contract between the .NET API and the React
> web app. Not needed for pure-DB or pure-frontend-styling work.

---

> **MERGE NOTE:** Paste your existing API + DTO content here. Suggested
> structure:
>
> ## 1. Conventions
> - REST: `/api/v1/{resource}`
> - All endpoints scoped by tenant via JWT — never accept `HCenterID` in
>   path or body
> - Soft-delete filter applied server-side; clients never see deleted rows
>
> ## 2. Endpoint inventory (by domain)
> Patients, visits, billing, scheduling, users, lookups…
> For each: HTTP method + path + auth + brief description.
>
> ## 3. DTO shapes
> Group by domain. Note where DTO differs from entity (computed fields,
> redactions, denormalizations).
>
> ## 4. Error envelope
> Standard problem-details JSON shape.
>
> Cross-refs:
> - Field-encryption columns → security-and-ops §2 ("field-level")
> - Audit log requirement on every read → security-and-ops §4
> - Legacy typo fields in DTOs → schema-quirks §typos
