# Schema — Patient history (general)

> **Load when:** working on allergies, chronic diseases, problems list,
> long-term medications, immunization history, lab requests, or hereditary
> diseases. For demographics, load `schema-patient-core.md`.
>
> **Tables:** `allergies`, `chronicdiseases`, `patientlongtermmedicines`,
> `patientproblems`, `pfihereditarydiseases`, `patientimmunizationhistory`,
> `patientimmunizations`, `patientlabrequests`.

**Legend** — **PK** · **FK→** · **NN**. `__sys*` omitted.

---

> **MERGE NOTE:** Paste your existing content for the 8 tables above here,
> compact format (one section per table, column tables only when needed).
> Cross-refs:
> - Enums → schema-quirks
> - FK to `medicalconditions`, `medicines`, `immunizationsvaccines` →
>   schema-reference
