# Design system

> **Load when:** styling a component, picking a color/spacing/typography
> token, or building a new modal/form. Not needed for pure-API or DB work.

---

> **MERGE NOTE:** Paste your existing design-system content here. Suggested
> structure:
>
> ## 1. Tokens
> Colors (semantic, not raw), spacing scale, typography scale, radii.
>
> ## 2. Form primitives
> The shared components in `web/src/lib/form-primitives.tsx`:
> `FieldLabel`, `TextInput`, `Textarea`, `Section`, `SelectFreeText`,
> `nonEmpty`, `diffString`, `toDateInput`.
> **Rule:** never inline-copy these into modals — see CLAUDE.md "Working in
> modals/forms."
>
> ## 3. RTL & bilingual
> - Use logical properties (`padding-inline-start`, `margin-inline-end`),
>   not `left`/`right`
> - Arabic fields always paired with English (see CLAUDE.md "RTL")
> - Reports: English + Arabic versions side by side
>
> ## 4. Component patterns
> Modal pattern, list pattern, detail pattern, empty state, loading,
> error state.
>
> ## 5. Accessibility baseline
> WCAG 2.1 AA. Focus rings, keyboard nav, ARIA on custom controls.
