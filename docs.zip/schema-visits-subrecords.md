# Schema — Visit sub-records

> **Load when:** working on any of the satellite tables that hang off a
> `patientvisits` row — recommendations, assessment conditions, past medical
> history snapshots, medication plans, prescriptions, revisits, pregnancy
> details, risk stratification, initial exam, prenatal flowsheet, fertility,
> PASI score. For the visit row itself, load `schema-visits-row.md`.
>
> **14 tables:** `aftervisitrecommendations`, `pvassessmentconditions`,
> `pvpmhconditions`, `pvpmhmedications`, `pvplanmedications`,
> `pvgprescription`, `pvrevisits`, `pvpregnancydetails`,
> `pvpriskstratificationchecks`, `pvpinitialexam`, `prenatalflowsheetitems`,
> `pvfertilitydetails`, `pvfertilityflowsheetitems`, `patientpasiscore`.

**Legend** — **PK** · **FK→** · **NN**. `__sys*` omitted.

---

> **MERGE NOTE:** Paste your existing content for the 14 tables here in the
> order listed. These are sub-records hanging off `patientvisits` — each
> table will have a `PatientVisitID` FK.
>
> Cross-refs:
> - `pvpriskstratificationchecks.intesity` (sic) → schema-quirks §typos
> - `pvpriskstratificationchecks` is wide (30 cols) — roadmap item #6 plans
>   to normalize. Note this at top of that section.
> - `pvpmhConditionId` casing → schema-quirks §typos
> - Medication FK to `medicines` → schema-reference
