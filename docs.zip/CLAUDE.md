# CLAUDE.md — Teriac project rules

This file is loaded on every turn. Keep it lean. Reference data lives in `docs/`
and is loaded on demand (see "When to load which doc" below).

---

## Always-on behavioral rules

### Hard rules (never break)
1. **Tenant safety.** Every query that touches a tenant-scoped table must filter
   by `HCenterID`. If a method has no `HCenterID` in scope, that's a bug — stop
   and ask, don't guess. See `docs/security-and-ops.md` §"Tenant Isolation" for
   the 4 lines of defense.
2. **Soft delete.** `patients` and `patientvisits` use `IsDeleted`. Never hard-
   delete. EF global filter is the source of truth; raw SQL must mirror it.
3. **PHI logging.** Every read and write of patient data must go through the
   audit log path. Don't bypass for "just a quick query."
4. **No new char(36) GUIDs as PKs in new tables.** Use `BINARY(16)` going
   forward (see roadmap item #9).

### Response style
- **No trailer.** Don't end replies with "Try it / Polish backlog / Where
  next?" sections unless the user asks. End when the answer ends.
- **No preamble.** Skip "Great question!" and "Let me help you with that."
- **Prose for explanations, lists only when the content is genuinely a list.**
- **Smoke tests:** pass/fail + 2-3 key columns, not full mysql --table dumps.

### RTL / bilingual
- Arabic name fields exist alongside English (`patientarabicinfo`,
  `ReportUsernameAr`, etc.). Forms that show one must show the other.
- Report templates have `*Ar` siblings — match the user's locale.

### Working in modals/forms
- Use the shared primitives in `web/src/lib/form-primitives.tsx` (FieldLabel,
  TextInput, Textarea, Section, SelectFreeText, nonEmpty, diffString,
  toDateInput). Do NOT inline-copy these into new modals.

---

## When to load which doc

Open the file with the Read tool only when the task matches. Do not pre-load.

| If the task involves… | Load |
|---|---|
| Patient demographics, registration, the patient edit modal | `docs/schema-patient-core.md` |
| Allergies, chronic diseases, problems, immunizations, long-term meds | `docs/schema-patient-history.md` |
| Pediatric or OB/GYN forms | `docs/schema-patient-pediatric-obgyn.md` |
| Visit row itself, visit creation, visit list | `docs/schema-visits-row.md` |
| Assessment conditions, plan medications, prescriptions, revisits, sub-records | `docs/schema-visits-subrecords.md` |
| Billing, invoices, wallets, the financial ledger | `docs/schema-billing.md` |
| Tenant settings, users, permissions, scheduling | `docs/schema-tenant-users.md` |
| ICD-10, CPT, HCPCS, body systems, growth percentiles, any lookup | `docs/schema-reference.md` |
| Foreign keys, indexes, performance tuning a query | `docs/schema-fks-indexes.md` |
| Legacy column typos (intesity, pvpmhConditionId, Fiftheeth, etc.) | `docs/schema-quirks.md` §typos |
| Enum values (Sex, VisitType, Outcome, TransactionType, UserType…) | `docs/schema-quirks.md` §enums |
| HIPAA, encryption, audit log, backups, deployment, k8s | `docs/security-and-ops.md` |
| Migration plan, open questions, things still TBD | `docs/roadmap-and-open-questions.md` |
| Acronym you don't recognize (PASI, TPAL, TORCH, etc.) | `docs/appendices.md` §B |
| "Which file is table X in?" | `docs/appendices.md` §A |
| API endpoints, DTOs, request/response shapes | `docs/api-and-dtos.md` |
| Component styling, colors, spacing, design tokens | `docs/design-system.md` |

**Multiple files are fine when the task spans domains** (e.g., a visit-billing
report needs visits-row + billing). Just don't open them speculatively.

---

## Project layout (one-line cheatsheet)

```
src/Teriac.Api/         .NET 8 API
src/Teriac.Domain/      EF entities, value objects
src/Teriac.Infra/       EF DbContext, migrations, repos
web/                    React + Vite, see docs/design-system.md
drizzle/schema.ts       Generated. Grep, don't read whole.
drizzle/relations.ts    Generated, unused. Ignore.
docs/                   This documentation set.
```

---

## Stack assumptions (so I don't keep re-checking)

- DB: MariaDB 11, InnoDB, `utf8mb4_unicode_ci`
- API: .NET 8, EF Core 8, Hangfire, Serilog
- Web: React 18 + Vite + TypeScript, Tailwind
- Auth: Keycloak (OIDC), JWT with `hcenter_id` claim
- Cache: Redis 7
- Storage: S3-compatible (MinIO in dev)
- Search: Meilisearch (ICD/CPT typeahead)

If any of these have changed, fix this section — don't work around it.
