# Schema — Patient core (master record)

> **Load when:** working on patient demographics, registration, the patient
> edit modal, search, or anything that reads/writes the core patient record.
> For allergies/chronic disease/problems/immunizations, load
> `schema-patient-history.md` instead. For pediatric/OB-GYN history, load
> `schema-patient-pediatric-obgyn.md`.
>
> **Tables in this file:** `patients`, `patientarabicinfo`,
> `patientadditionalinfo`, `patientsaddetails`, `patientjobs`,
> `patienteducationalhistory`, `patientspecialnotes`, `patientchecklist`,
> `patienttestbehaviors`, `patientinsurancedetails`.

**Legend** — **PK** · **FK→** · **NN**. `__sys*` trailers omitted.

---

> **MERGE NOTE:** Paste your existing column-by-column content for the 10
> tables above here, in the order listed. Keep the same compact format used
> in `schema-billing.md` and `schema-tenant-users.md` (table-per-section,
> column tables only for non-trivial tables).
>
> Cross-references to fix during the paste:
> - `Sex` enum → say "see schema-quirks §enums", don't restate values
> - Any `__sys*` columns → omit
> - Typos like `NationalID` casing differences → flag in schema-quirks
> - `OnlinePassword` → note "see security-and-ops §3; open question #10"
