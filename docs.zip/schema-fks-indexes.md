# Schema — Foreign keys & indexes

> **Load when:** writing a migration that adds FKs/indexes, performance-
> tuning a slow query, or designing the data-quality probe set. Not needed
> for routine application code.

---

> **MERGE NOTE:** Paste your existing FK and index DDL here. Suggested
> structure:
>
> ## 1. Foreign keys (80+)
> Group by referenced table. For each: `ALTER TABLE … ADD CONSTRAINT …
> FOREIGN KEY (…) REFERENCES … (…) ON DELETE … ON UPDATE …;`
>
> ## 2. Indexes (40+)
> Group by table. For each: name, columns, type (BTREE/FULLTEXT),
> rationale (which query pattern it serves — cross-ref to
> security-and-ops §9).
>
> ## 3. Composite-index design notes
> Standard reporting predicate: `(HCenterID, …, AddDate)`.
> Patient typeahead: FULLTEXT on names.
> ICD/CPT: FULLTEXT or Meilisearch.
>
> ## 4. Order of application
> FKs require orphan cleanup first — see roadmap §2.
