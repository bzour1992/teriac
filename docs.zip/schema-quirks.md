# Schema quirks — typos, enums, gotchas

> **Load when:** working with the schema and hitting a name that looks misspelled,
> or needing to interpret an `int(11)` column that's actually an enum.

---

## §typos — Legacy column-name typos to preserve

These typos are baked into the database. Do **not** "fix" them in code — match
them exactly. Use `// legacy spelling` comments where they appear in DTOs.

| Table | Column as stored | Intended | Notes |
|---|---|---|---|
| `wallets` | `IsCacheBox` | `IsCashBox` | Cash box flag |
| `hcenterusers` | `eCliamProfessionalName` | `eClaimProfessionalName` | UAE eClaim Link field |
| `medicines` | `scientificName` | `ScientificName` | Lowercase first letter (others are PascalCase) |
| `age*percentiles` | `FifteethPercentile` | `FiftiethPercentile` | 50th %ile |
| `age*percentiles` | `NineteethPercentile` | `NinetiethPercentile` | 90th %ile |
| `age*percentiles` | `NintyFifthPercentile` | `NinetyFifthPercentile` | 95th %ile |
| `age*percentiles` | `NintySeventhPercentile` | `NinetySeventhPercentile` | 97th %ile |
| (visit risk strat) | `intesity` | `intensity` | Reported by app team |
| (visit PMH) | `pvpmhConditionId` | `pvpmhConditionID` | Casing inconsistency |

If you discover a new typo not listed here, add it to this table in the same PR
that handles it.

---

## §enums — Integer enum reference

All `int(11)` and `tinyint(1)` columns listed here are enums. Values come from
the legacy client app and **must not be re-numbered**. New values append at the
end.

> Marked **CONFIRMED** are verified from code; **ASSUMED** still need owner
> sign-off (see `docs/roadmap-and-open-questions.md` #1).

### `patients.Sex` — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Male |
| 2 | Female |
| 3 | Other / unspecified |

### `patientvisits.VisitType` — ASSUMED
| Value | Meaning |
|---|---|
| 1 | New visit |
| 2 | Follow-up |
| 3 | Emergency |
| 4 | Telemedicine |
| 5 | Surgical |

### `patientvisits.Outcome` — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Resolved |
| 2 | Improved |
| 3 | Unchanged |
| 4 | Worsened |
| 5 | Failed |
| 6 | Referred out |

### `pvpriskstratificationchecks.intesity` *(sic)* — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Low |
| 2 | Moderate |
| 3 | High |
| 4 | Critical |

### `hcenterfinancaltransactions.TransactionType` — CONFIRMED
| Value | Meaning |
|---|---|
| 1 | Income |
| 2 | Expense |
| 3 | Transfer |
| 4 | Refund |
| 5 | Salary |

### `hcenters.SubscriptionType` — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Trial |
| 2 | Basic |
| 3 | Premium |
| 4 | Enterprise |

### `hcenterusers.UserType` — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Doctor |
| 2 | Nurse |
| 3 | Receptionist |
| 4 | Admin |
| 5 | Lab technician |
| 6 | Pharmacist |
| 7 | Optometrist |

### `patientvisits.DeliveryType` — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Vaginal |
| 2 | C-section (elective) |
| 3 | C-section (emergency) |
| 4 | Assisted (forceps/vacuum) |

### `diagnostictests.DiagnosticTestType` — CONFIRMED
| Value | Meaning |
|---|---|
| 1 | Laboratory |
| 2 | Imaging |
| 3 | Cardiac (EKG/Echo) |
| 4 | Other |

### `icd10-cm2012.Type` — CONFIRMED
| Value | Meaning |
|---|---|
| 1 | Header (non-billable parent code) |
| 2 | Billable leaf |

### `denverscreeningtestitems.ItemCategory` — CONFIRMED
| Value | Meaning |
|---|---|
| 1 | Personal-Social |
| 2 | Fine Motor |
| 3 | Language |
| 4 | Gross Motor |

### `age*percentiles.Gender` — CONFIRMED
| Value | Meaning |
|---|---|
| 1 | Male |
| 2 | Female |

### `hcentersystemsettings.IsPatientAddressRequired` *(and similar `int(11)` "required" flags)*
| Value | Meaning |
|---|---|
| 0 | Not shown |
| 1 | Optional |
| 2 | Required |

### `hcenterscheduleitems.LabelID` — color labels — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Default |
| 2 | Red (urgent) |
| 3 | Yellow (tentative) |
| 4 | Green (confirmed) |
| 5 | Blue (follow-up) |
| 6 | Purple (VIP) |

### `hcenterscheduleitems.StatusID` — workflow — ASSUMED
| Value | Meaning |
|---|---|
| 1 | Scheduled |
| 2 | Checked in |
| 3 | In progress |
| 4 | Completed |
| 5 | No-show |
| 6 | Cancelled |

---

## §gotchas — Schema behaviors that surprise people

1. **`patientvisits` has no `HCenterID`.** Tenant filtering currently goes
   through `patients.HCenterID`. Roadmap item #5 adds the column denormalized.
   Until then, every visit query joins `patients`.

2. **`hcenterusers` has no password column.** Auth is external (Keycloak).
   Don't add one — see `docs/security-and-ops.md` §12.2.

3. **GUIDs are stored as `char(36)`**, not `BINARY(16)`. New code should keep
   using char(36) for now (consistency with existing FKs); migration is
   roadmap item #9.

4. **`hcenterfinancaltransactions` is polymorphic.** A single row may link to
   a billing record, an invoice, an insurance detail, an employee, OR an
   inventory item — but only one at a time. The `TransactionType` enum is
   the discriminator. See `docs/schema-billing.md` for the column groupings.

5. **`__sysChangeTxBsn`, `__sysInsertTxBsn`, `__sysTrackingContext`** trail
   every domain table — they're from the Devart offline sync engine and are
   omitted from per-column tables in the schema docs. Treat them as opaque;
   don't query, don't write.

6. **`InventoryItemID` is referenced but no inventory tables are visible** in
   the dump. Confirm with owner before building inventory features
   (roadmap open question #9).

7. **`wallets` has no currency column** — multi-currency tenants are not yet
   supported (open question #8).
